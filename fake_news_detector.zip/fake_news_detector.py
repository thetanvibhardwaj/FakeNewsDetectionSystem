import pandas as pd
import re
import string
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Load dataset
fake = pd.read_csv("dataset/Fake.csv")
real = pd.read_csv("dataset/True.csv")
fake["label"] = 0  # FAKE
real["label"] = 1  # REAL

# Combine and preprocess
data = pd.concat([fake, real])[["title", "text", "label"]]
data["content"] = data["title"] + " " + data["text"]

# Clean text function
def clean_text(text):
    text = text.lower()
    text = re.sub(r'https?://\S+|www\.\S+', '', text)
    text = re.sub(r'<.*?>+', '', text)
    text = re.sub(r'[^\w\s\.\,\-]', '', text)
    text = re.sub(r'\n', ' ', text)
    return text.strip()

# Apply cleaning
data["content"] = data["content"].apply(clean_text)

# Check how many real news samples exist
print("\nNumber of samples in REAL dataset:", len(real))

# Split data
X = data["content"]
y = data["label"]
print("\nDataset Balance:")
print(data['label'].value_counts())
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Vectorize text
vectorizer = TfidfVectorizer(stop_words="english", max_df=0.7)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Train model
model = LogisticRegression(max_iter=1000)
model.fit(X_train_vec, y_train)

# Evaluate model
accuracy = accuracy_score(y_test, model.predict(X_test_vec))
print("\n======================================")
print("   FAKE NEWS DETECTION - CMD VERSION  ")
print("======================================")
print(f"Model Accuracy on Test Data: {round(accuracy * 100, 2)}%")

# Prediction function
def predict_news(news):
    cleaned = clean_text(news)
    vect = vectorizer.transform([cleaned])
    prob = model.predict_proba(vect)[0]
    pred = model.predict(vect)[0]
    
    print(f"Confidence: REAL = {prob[1]*100:.2f}%, FAKE = {prob[0]*100:.2f}%")

    if abs(prob[1] - prob[0]) < 0.2:
        return "UNSURE / LOW CONFIDENCE"
    return "REAL" if pred == 1 else "FAKE"
  
# Command line loop
while True:
    news = input("\nEnter news to check (or type 'exit' to quit):\n")
    if news.lower() == "exit":
        print("Exiting... Thank you!")
        break
    print("Prediction:", predict_news(news))
